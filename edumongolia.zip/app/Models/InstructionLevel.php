<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class InstructionLevel extends Model
{
    protected $table = 'instruction_levels';
    public $timestamps = false;
    protected $guarded = array();
    
}
